import numpy as np
import pandas as pd
import os


import argparse

parser = argparse.ArgumentParser(description='Process some integers.')
parser.add_argument('-p', type=str )

args = parser.parse_args()
print(args.p)

os.chdir(args.p)

ordered_files = sorted([f for f in os.listdir() if f.endswith('.csv')], key= lambda x: int(x[13:13 + x[13:].find('_')]))
means=[]
stds=[]
print('PRINTING MEANS')
for file in ordered_files:
    df = pd.read_csv(file)
    print(round(float(df.mean()),1))
    means.append(round(float(df.mean()),1))

print('PRINTING STD') 
for file in ordered_files:
    df = pd.read_csv(file)
    print(round(float(df.std()),1))
    stds.append(round(float(df.std()),1))

np.savetxt("means.txt", means, delimiter ="\n", fmt='%.1f')
np.savetxt("stds.txt", stds, delimiter ="\n", fmt='%.1f')
    



